package com.example.insuranceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class master extends AppCompatActivity {

   // RadioButton prodABC, prodDEF, prodGHI;
    //TextView output;
   // RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_master);

        //prodABC = findViewById(R.id.prodABC);
       // prodDEF = findViewById(R.id.prodDEF);
        //prodGHI = findViewById(R.id.prodGHI);
        //output = findViewById(R.id.output);
       // radioGroup = findViewById(R.id.radioGroup);

    }
}
